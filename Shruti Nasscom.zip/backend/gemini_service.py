import os
import json
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

class GeminiService:
    def __init__(self):
        self.api_key = GEMINI_API_KEY
        self.client = None
        if self.api_key and self.api_key != "your_gemini_api_key_here":
            try:
                from google import genai
                self.client = genai.Client(api_key=self.api_key)
            except Exception as e:
                print(f"[GeminiService] Note: google-genai client init: {e}")

    def generate_financial_advice(self, data: dict) -> dict:
        currency = data.get("currency", "₹")
        income = float(data.get("income", 0))
        other_income = float(data.get("otherIncome", 0))
        total_income = income + other_income
        expenses = data.get("expenses", {})
        
        total_expenses = sum(float(v or 0) for v in expenses.values())
        available_balance = total_income - total_expenses

        if self.client:
            try:
                prompt = f"""
You are VanguardIQ, a certified personal finance assistant.
Analyze this profile:
- Monthly Income: {currency}{income}
- Other Income: {currency}{other_income}
- Expenses: {json.dumps(expenses)}
- Goal: {data.get('financialGoal')}
- Target Amount: {currency}{data.get('targetAmount')}
- Current Savings: {currency}{data.get('currentSavings')}
- Target Horizon: {data.get('targetDate')}
- Risk: {data.get('riskPreference')}
- Notes: {data.get('notes', '')}

Return ONLY valid JSON matching this schema:
{{
  "budget_plan": {{
    "total_income": number,
    "total_expenses": number,
    "available_balance": number,
    "needs": {{
      "total": number,
      "percentage": number,
      "breakdown": {{"housing": number, "food": number, "transportation": number, "utilities": number, "healthcare": number, "education": number}}
    }},
    "wants": {{
      "total": number,
      "percentage": number,
      "breakdown": {{"entertainment": number, "shopping": number, "other": number}}
    }},
    "savings": {{
      "recommended_monthly": number,
      "actual_surplus": number,
      "percentage": number
    }},
    "rule_50_30_20_comparison": {{
      "needs_ideal": number,
      "wants_ideal": number,
      "savings_ideal": number,
      "status": string
    }}
  }},
  "saving_suggestions": [
    {{
      "id": string,
      "title": string,
      "explanation": string,
      "potential_saving": string,
      "priority": "High" | "Medium" | "Low",
      "category": string
    }}
  ],
  "monthly_summary": {{
    "health_score": string,
    "health_score_num": number,
    "overall_summary": string,
    "biggest_category": string,
    "savings_progress": string,
    "positive_observation": string,
    "area_to_improve": string,
    "next_month_focus": string
  }},
  "insights": [
    {{
      "title": string,
      "value": string,
      "description": string
    }}
  ]
}}
"""
                response = self.client.models.generate_content(
                    model="gemini-3.8-flash",
                    contents=prompt,
                    config={
                        "response_mime_type": "application/json"
                    }
                )
                if response.text:
                    return json.loads(response.text)
            except Exception as e:
                print(f"[GeminiService] Gemini call failed, falling back to algorithmic plan: {e}")

        # Deterministic fallback
        target_savings = max(0, round(total_income * 0.2))
        savings_rate = round((available_balance / total_income * 100)) if total_income > 0 else 0
        housing = float(expenses.get("housing", expenses.get("Rent / Housing", 0)))
        food = float(expenses.get("food", expenses.get("Food", 0)))
        transport = float(expenses.get("transportation", expenses.get("Transportation", 0)))
        utilities = float(expenses.get("utilities", expenses.get("Utilities", 0)))
        healthcare = float(expenses.get("healthcare", expenses.get("Healthcare", 0)))
        education = float(expenses.get("education", expenses.get("Education", 0)))
        entertainment = float(expenses.get("entertainment", expenses.get("Entertainment", 0)))
        shopping = float(expenses.get("shopping", expenses.get("Shopping", 0)))
        other = float(expenses.get("other", expenses.get("Other", 0)))

        needs = housing + food + transport + utilities + healthcare + education
        wants = entertainment + shopping + other

        return {
            "budget_plan": {
                "total_income": total_income,
                "total_expenses": total_expenses,
                "available_balance": available_balance,
                "needs": {
                    "total": needs,
                    "percentage": round(needs / total_income * 100) if total_income else 0,
                    "breakdown": {
                        "housing": housing, "food": food, "transportation": transport,
                        "utilities": utilities, "healthcare": healthcare, "education": education
                    }
                },
                "wants": {
                    "total": wants,
                    "percentage": round(wants / total_income * 100) if total_income else 0,
                    "breakdown": {"entertainment": entertainment, "shopping": shopping, "other": other}
                },
                "savings": {
                    "recommended_monthly": target_savings,
                    "actual_surplus": available_balance,
                    "percentage": savings_rate
                },
                "rule_50_30_20_comparison": {
                    "needs_ideal": round(total_income * 0.5),
                    "wants_ideal": round(total_income * 0.3),
                    "savings_ideal": round(total_income * 0.2),
                    "status": "Optimal" if savings_rate >= 20 else "Balanced" if savings_rate >= 10 else "Needs Optimization"
                }
            },
            "saving_suggestions": [
                {
                    "id": "sug-1",
                    "title": "Reduce Dining & Food Delivery",
                    "explanation": f"Your food spending is {currency}{int(food):,}. Meal-prepping 2 days a week can easily recapture 15-20% of this budget.",
                    "potential_saving": f"{currency}{int(food * 0.18):,}/month",
                    "priority": "High",
                    "category": "Food"
                },
                {
                    "id": "sug-2",
                    "title": "Streamline Digital Subscriptions",
                    "explanation": "Audit recurring OTT, fitness apps, and entertainment subscriptions for forgotten recurring charges.",
                    "potential_saving": f"{currency}800/month",
                    "priority": "Medium",
                    "category": "Entertainment"
                },
                {
                    "id": "sug-3",
                    "title": "Automate Salary Day Savings Transfer",
                    "explanation": f"Schedule an auto-debit of {currency}{int(target_savings * 0.7):,} right on payday to prevent accidental discretionary overspending.",
                    "potential_saving": f"{currency}{int(target_savings * 0.15):,}/month",
                    "priority": "High",
                    "category": "Savings"
                }
            ],
            "monthly_summary": {
                "health_score": "Strong" if savings_rate >= 20 else "Moderate" if savings_rate >= 10 else "Strained",
                "health_score_num": min(95, max(40, savings_rate * 3 + 30)),
                "overall_summary": f"Your monthly surplus stands at {currency}{int(available_balance):,} ({savings_rate}% savings rate). You are on track for your goal with sustainable cash flow.",
                "biggest_category": f"Housing ({currency}{int(housing):,})" if housing > food else f"Food ({currency}{int(food):,})",
                "savings_progress": f"{currency}{int(float(data.get('currentSavings', 0))):,} saved towards {currency}{int(float(data.get('targetAmount', 150000))):,} goal.",
                "positive_observation": f"Maintained positive cash flow buffer of {currency}{int(available_balance):,} per month.",
                "area_to_improve": f"Discretionary expenditure takes up {currency}{int(wants):,} ({round(wants/total_income*100) if total_income else 0}%).",
                "next_month_focus": "Set up an automatic recurring deposit to lock in your surplus."
            },
            "insights": [
                {
                    "title": "Cash Flow Buffer",
                    "value": f"{max(1, int(float(data.get('currentSavings', 0)) / (total_expenses or 1)))} months",
                    "description": "Months of basic living expenses covered by current liquid savings."
                },
                {
                    "title": "Savings Efficiency",
                    "value": f"{savings_rate}%",
                    "description": "Standard benchmark suggests 20% of net income."
                }
            ]
        }
