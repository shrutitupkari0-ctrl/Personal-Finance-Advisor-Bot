import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
from gemini_service import GeminiService

load_dotenv()

app = Flask(__name__)
CORS(app)

gemini_service = GeminiService()

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "gemini_configured": bool(os.getenv("GEMINI_API_KEY")),
        "service": "VanguardIQ Flask API"
    })

@app.route("/api/financial-advice", methods=["POST"])
def financial_advice():
    data = request.get_json() or {}
    try:
        advice = gemini_service.generate_financial_advice(data)
        return jsonify({"success": True, "data": advice})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/chat-advice", methods=["POST"])
def chat_advice():
    data = request.get_json() or {}
    question = data.get("question", "")
    context = data.get("financialContext", {})
    currency = context.get("currency", "₹")

    # If Gemini service client is available
    if gemini_service.client:
        try:
            prompt = f"""
You are VanguardIQ, a pragmatic personal finance advisor.
Context:
- Monthly Income: {currency}{context.get('income', 55000)}
- Expenses: {currency}{context.get('totalExpenses', 40000)}
- Goal: {context.get('financialGoal', 'Emergency Fund')} (Target: {currency}{context.get('targetAmount', 150000)})

User Question: {question}

Provide an actionable, friendly markdown response with numerical clarity and practical advice.
"""
            res = gemini_service.client.models.generate_content(
                model="gemini-3.8-flash",
                contents=prompt
            )
            return jsonify({"success": True, "answer": res.text})
        except Exception as e:
            print("Gemini chat error:", e)

    # Fallback answer
    return jsonify({
        "success": True,
        "answer": f"To optimize your finances based on your profile: automate savings of {currency}{int(float(context.get('income', 50000))*0.2):,} directly to your reserve, keep discretionary spend below 30%, and maintain 3–6 months in emergency reserves."
    })

if __name__ == "__main__":
    port = int(os.getenv("FLASK_PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
