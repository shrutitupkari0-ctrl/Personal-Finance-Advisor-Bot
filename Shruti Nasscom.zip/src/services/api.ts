import { UserFinancialInput, FinancialAdviceResponse } from '../types/finance';
import { DEMO_ADVICE_RESPONSE } from '../utils/demoData';

export async function fetchFinancialAdvice(input: UserFinancialInput): Promise<FinancialAdviceResponse> {
  try {
    const response = await fetch('/api/financial-advice', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(input),
    });

    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}`);
    }

    const json = await response.json();
    if (json.success && json.data) {
      return json.data;
    }
    throw new Error(json.error || 'Invalid API response');
  } catch (err) {
    console.warn('API error, using local financial analyzer fallback:', err);
    // Calculate client-side fallback if network fails
    return calculateLocalAdvice(input);
  }
}

export async function askFinancialChat(
  question: string,
  financialContext: any,
  history: { role: string; content: string }[] = []
): Promise<string> {
  try {
    const response = await fetch('/api/chat-advice', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ question, financialContext, history }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}`);
    }

    const json = await response.json();
    if (json.success && json.answer) {
      return json.answer;
    }
    throw new Error(json.error || 'Failed to retrieve response');
  } catch (err) {
    console.warn('Chat API error, using contextual fallback:', err);
    const curr = financialContext?.currency || '₹';
    return `### VanguardIQ Guidance
Thank you for your question about **"${question}"**.

**Key Financial Takeaways:**
1. **Pay Yourself First:** Automate your core savings right when your salary arrives.
2. **50/30/20 Rule:** Keep core needs under 50%, discretionary wants under 30%, and channel 20%+ directly into liquid savings.
3. **Emergency Moat:** Ensure you maintain 3 to 6 months of expenses in a dedicated high-yield account.

*Note: All VanguardIQ recommendations are educational planning tools rather than certified investment advice.*`;
  }
}

function calculateLocalAdvice(data: UserFinancialInput): FinancialAdviceResponse {
  const currency = data.currency || '₹';
  const totalIncome = Number(data.income || 0) + Number(data.otherIncome || 0);
  const exp = data.expenses || {};
  let totalExpenses = 0;
  for (const k in exp) {
    totalExpenses += Number(exp[k] || 0);
  }

  const housing = Number(exp.housing || 0);
  const food = Number(exp.food || 0);
  const transportation = Number(exp.transportation || 0);
  const utilities = Number(exp.utilities || 0);
  const healthcare = Number(exp.healthcare || 0);
  const education = Number(exp.education || 0);

  const entertainment = Number(exp.entertainment || 0);
  const shopping = Number(exp.shopping || 0);
  const other = Number(exp.other || 0);

  const needsTotal = housing + food + transportation + utilities + healthcare + education;
  const wantsTotal = entertainment + shopping + other;
  const balance = totalIncome - totalExpenses;
  const recommendedSavings = Math.max(0, Math.round(totalIncome * 0.2));
  const savingsRate = totalIncome > 0 ? Math.round((balance / totalIncome) * 100) : 0;

  const targetAmount = Number(data.targetAmount || 100000);
  const currentSavings = Number(data.currentSavings || 0);
  const remaining = Math.max(0, targetAmount - currentSavings);
  const monthlyPace = balance > 0 ? balance : 2000;
  const months = Math.ceil(remaining / monthlyPace);

  return {
    budget_plan: {
      total_income: totalIncome,
      total_expenses: totalExpenses,
      available_balance: balance,
      needs: {
        total: needsTotal,
        percentage: totalIncome > 0 ? Math.round((needsTotal / totalIncome) * 100) : 0,
        breakdown: { housing, food, transportation, utilities, healthcare, education },
      },
      wants: {
        total: wantsTotal,
        percentage: totalIncome > 0 ? Math.round((wantsTotal / totalIncome) * 100) : 0,
        breakdown: { entertainment, shopping, other },
      },
      savings: {
        recommended_monthly: recommendedSavings,
        actual_surplus: balance,
        percentage: savingsRate,
      },
      rule_50_30_20_comparison: {
        needs_ideal: Math.round(totalIncome * 0.5),
        wants_ideal: Math.round(totalIncome * 0.3),
        savings_ideal: Math.round(totalIncome * 0.2),
        status: savingsRate >= 20 ? 'Optimal' : savingsRate >= 10 ? 'Balanced' : 'Needs Optimization',
      },
    },
    saving_suggestions: [
      {
        id: 'sug-1',
        title: 'Dining & Food Spend Optimization',
        explanation: `Food takes up ${currency}${food.toLocaleString()} monthly. Reducing takeout orders by 2 days a week provides immediate budget relief without compromising nutrition.`,
        potential_saving: `${currency}${Math.round(food * 0.15 || 1500).toLocaleString()}/month`,
        priority: 'High',
        category: 'Food',
      },
      {
        id: 'sug-2',
        title: 'Discretionary Cooling-off Rule',
        explanation: 'Enforce a 48-hour wait period for all non-essential shopping items exceeding 2% of your monthly pay.',
        potential_saving: `${currency}${Math.round(shopping * 0.25 || 1000).toLocaleString()}/month`,
        priority: 'Medium',
        category: 'Shopping',
      },
      {
        id: 'sug-3',
        title: 'Utility & Data Subscriptions Audit',
        explanation: 'Audit mobile plans, broadband speed tiers, and multiple active media subscriptions.',
        potential_saving: `${currency}${Math.round(utilities * 0.15 || 500).toLocaleString()}/month`,
        priority: 'Low',
        category: 'Utilities',
      },
      {
        id: 'sug-4',
        title: 'Automated Payday Goal Transfer',
        explanation: `Set up an automated standing order of ${currency}${Math.round(recommendedSavings * 0.8).toLocaleString()} directly into your goal reserve on salary day.`,
        potential_saving: `${currency}${Math.round(recommendedSavings * 0.25).toLocaleString()}/month`,
        priority: 'High',
        category: 'Savings',
      },
    ],
    monthly_summary: {
      health_score: savingsRate >= 20 ? 'Strong' : savingsRate >= 10 ? 'Moderate' : 'Strained',
      health_score_num: Math.min(95, Math.max(35, savingsRate * 3 + 25)),
      overall_summary: `Your cash flow maintains a net surplus of ${currency}${balance.toLocaleString()} per month (${savingsRate}% savings rate). You have reached ${Math.round((currentSavings / (targetAmount || 1)) * 100)}% of your target '${data.financialGoal}', projecting completion in ~${months} months.`,
      biggest_category: `Housing (${currency}${housing.toLocaleString()})`,
      savings_progress: `${currency}${currentSavings.toLocaleString()} saved towards ${currency}${targetAmount.toLocaleString()} target.`,
      positive_observation: `You maintain a positive cash flow surplus of ${currency}${balance.toLocaleString()} each month.`,
      area_to_improve: `Discretionary wants total ${currency}${wantsTotal.toLocaleString()} (${totalIncome > 0 ? Math.round((wantsTotal / totalIncome) * 100) : 0}% of net income).`,
      next_month_focus: `Automate your ${currency}${recommendedSavings.toLocaleString()} monthly savings right on payday.`,
    },
    insights: [
      {
        title: 'Emergency Runway',
        value: `${Math.max(0, Math.floor(currentSavings / (totalExpenses || 1)))} months`,
        description: 'Months of living expenses covered by current liquid savings.',
      },
      {
        title: 'Savings Efficiency',
        value: `${savingsRate}%`,
        description: savingsRate >= 20 ? 'Exceeds standard 20% rule' : 'Target is at least 20%',
      },
    ],
  };
}
