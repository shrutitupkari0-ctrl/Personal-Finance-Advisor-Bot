import React, { useState, useEffect } from 'react';
import {
  CurrencySymbol,
  UserFinancialInput,
  FinancialAdviceResponse,
} from './types/finance';
import { DEMO_FINANCIAL_INPUT, DEMO_ADVICE_RESPONSE } from './utils/demoData';
import { fetchFinancialAdvice } from './services/api';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LandingPage } from './components/LandingPage';
import { FinanceForm } from './components/FinanceForm';
import { DashboardOverview } from './components/DashboardOverview';
import { BudgetPlanView } from './components/BudgetPlanView';
import { SavingsView } from './components/SavingsView';
import { WhatIfSimulator } from './components/WhatIfSimulator';
import { AIAdvisorChat } from './components/AIAdvisorChat';
import { LoadingAnalysis } from './components/LoadingAnalysis';
import { DisclaimerModal } from './components/DisclaimerModal';
import { ShieldAlert, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  // Theme State: Day / Night
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('vanguard_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Currency State (default INR as specified)
  const [currency, setCurrency] = useState<CurrencySymbol>('₹');

  // Navigation State
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);

  // Financial Data State
  const [userData, setUserData] = useState<UserFinancialInput>(DEMO_FINANCIAL_INPUT);
  const [advice, setAdvice] = useState<FinancialAdviceResponse | null>(null);

  // Status & Modal State
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showDisclaimer, setShowDisclaimer] = useState<boolean>(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Sync dark mode class with HTML and Body elements
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      localStorage.setItem('vanguard_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      localStorage.setItem('vanguard_theme', 'light');
    }
  }, [isDarkMode]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  // Demo Mode Activation
  const handleTryDemo = () => {
    setUserData(DEMO_FINANCIAL_INPUT);
    setAdvice(DEMO_ADVICE_RESPONSE);
    setCurrency('₹');
    setCurrentTab('dashboard');
    showToast('Loaded realistic ₹55,000 monthly income demo profile!');
  };

  // Handle Form Submission
  const handleFormSubmit = async (formData: UserFinancialInput) => {
    setUserData(formData);
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const generatedAdvice = await fetchFinancialAdvice(formData);
      setAdvice(generatedAdvice);
      setCurrentTab('dashboard');
      showToast('Your personalized AI Financial Plan is ready!');
    } catch (err: any) {
      console.error('Failed to generate advice:', err);
      setErrorMsg('Could not reach AI analysis server. Using algorithmic backup plan.');
      // Fallback to sample demo advice
      setAdvice(DEMO_ADVICE_RESPONSE);
      setCurrentTab('dashboard');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCurrencyChange = (newCurrency: CurrencySymbol) => {
    setCurrency(newCurrency);
    setUserData((prev) => ({ ...prev, currency: newCurrency }));
    showToast(`Currency updated to ${newCurrency}`);
  };

  const totalExpensesComputed = userData
    ? Object.values(userData.expenses || {}).reduce((a, b) => a + (Number(b) || 0), 0) +
      (userData.customExpenses?.reduce((a, b) => a + (Number(b.amount) || 0), 0) || 0)
    : 40000;

  const totalIncomeComputed = userData
    ? Number(userData.income || 0) + Number(userData.otherIncome || 0)
    : 55000;

  const monthlySurplusComputed = advice
    ? advice.budget_plan.available_balance
    : totalIncomeComputed - totalExpensesComputed;

  return (
    <div className={`min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200 ${isDarkMode ? 'dark' : ''}`}>
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-20 right-4 z-50 max-w-sm px-4 py-3 rounded-2xl bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-xl border border-slate-700 dark:border-slate-300 text-xs font-semibold flex items-center gap-2.5 animate-in slide-in-from-top-3 duration-200">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Top Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        currency={currency}
        onCurrencyChange={handleCurrencyChange}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        onTryDemo={handleTryDemo}
        onNewPlan={() => setCurrentTab('form')}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        hasPlan={Boolean(advice)}
      />

      {/* Main Layout Area */}
      <div className="flex-1 flex w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Responsive Desktop & Mobile Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          hasPlan={Boolean(advice)}
          healthScore={advice?.monthly_summary?.health_score}
          healthScoreNum={advice?.monthly_summary?.health_score_num}
          availableBalance={monthlySurplusComputed}
          currency={currency}
        />

        {/* Content Viewport */}
        <main className="flex-1 min-w-0 py-2 sm:py-4 lg:pl-8">
          {isLoading ? (
            <LoadingAnalysis />
          ) : (
            <>
              {errorMsg && (
                <div className="mb-4 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* View 1: Landing Page */}
              {currentTab === 'landing' && (
                <LandingPage
                  onCreatePlan={() => setCurrentTab('form')}
                  onTryDemo={handleTryDemo}
                  currency={currency}
                />
              )}

              {/* View 2: Financial Assessment Form */}
              {currentTab === 'form' && (
                <FinanceForm
                  initialData={userData}
                  currency={currency}
                  onCurrencyChange={handleCurrencyChange}
                  onSubmit={handleFormSubmit}
                  isLoading={isLoading}
                  onLoadDemo={handleTryDemo}
                />
              )}

              {/* View 3: Dashboard Overview */}
              {currentTab === 'dashboard' && advice && (
                <DashboardOverview
                  advice={advice}
                  userData={userData}
                  currency={currency}
                  onNavigate={setCurrentTab}
                />
              )}

              {/* View 4: Budget Plan */}
              {currentTab === 'budget' && advice && (
                <BudgetPlanView
                  budgetPlan={advice.budget_plan}
                  currency={currency}
                  financialGoal={userData.financialGoal}
                  targetAmount={userData.targetAmount}
                  currentSavings={userData.currentSavings}
                  onNavigateToSimulator={() => setCurrentTab('what-if')}
                />
              )}

              {/* View 5: Savings & AI Suggestions */}
              {currentTab === 'savings' && advice && (
                <SavingsView
                  suggestions={advice.saving_suggestions}
                  currency={currency}
                  financialGoal={userData.financialGoal}
                  targetAmount={userData.targetAmount}
                  currentSavings={userData.currentSavings}
                  monthlySurplus={advice.budget_plan.available_balance}
                  onNavigateToSimulator={() => setCurrentTab('what-if')}
                />
              )}

              {/* View 6: What-If Simulator */}
              {currentTab === 'what-if' && (
                <WhatIfSimulator
                  initialIncome={totalIncomeComputed}
                  initialExpenses={totalExpensesComputed}
                  currency={currency}
                  targetGoal={userData?.financialGoal || 'Emergency fund'}
                  targetAmount={userData?.targetAmount || 150000}
                  currentSavings={userData?.currentSavings || 40000}
                />
              )}

              {/* View 7: Ask FinWise AI Advisor */}
              {currentTab === 'advisor' && (
                <AIAdvisorChat
                  userData={userData}
                  currency={currency}
                  monthlySurplus={monthlySurplusComputed}
                  totalExpenses={totalExpensesComputed}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Global Bottom Disclaimer Strip */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/70 backdrop-blur-xs py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400 text-center sm:text-left">
          <div className="flex items-center gap-1.5 justify-center sm:justify-start">
            <ShieldAlert className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>
              VanguardIQ provides estimates and educational financial insights. It does not provide professional financial, investment, tax, or legal advice, and its recommendations do not guarantee financial outcomes.
            </span>
          </div>

          <button
            onClick={() => setShowDisclaimer(true)}
            className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline shrink-0"
          >
            Read Disclaimer
          </button>
        </div>
      </footer>

      {/* Disclaimer Modal */}
      <DisclaimerModal
        isOpen={showDisclaimer}
        onClose={() => setShowDisclaimer(false)}
      />
    </div>
  );
}
