import { UserFinancialInput, FinancialAdviceResponse } from '../types/finance';

export const DEMO_FINANCIAL_INPUT: UserFinancialInput = {
  income: 50000,
  otherIncome: 5000,
  currency: '₹',
  expenses: {
    housing: 15000,
    food: 7000,
    transportation: 4000,
    utilities: 3000,
    entertainment: 3000,
    shopping: 4000,
    education: 0,
    healthcare: 2000,
    other: 2000,
  },
  customExpenses: [],
  financialGoal: 'Build an emergency fund',
  targetAmount: 150000,
  targetDate: '12 months',
  currentSavings: 40000,
  riskPreference: 'Balanced',
  notes: 'Planning to secure a 6-month safety net in a high-yield liquid account.',
};

export const DEMO_ADVICE_RESPONSE: FinancialAdviceResponse = {
  budget_plan: {
    total_income: 55000,
    total_expenses: 40000,
    available_balance: 15000,
    needs: {
      total: 31000,
      percentage: 56,
      breakdown: {
        housing: 15000,
        food: 7000,
        transportation: 4000,
        utilities: 3000,
        healthcare: 2000,
        education: 0,
      },
    },
    wants: {
      total: 9000,
      percentage: 16,
      breakdown: {
        entertainment: 3000,
        shopping: 4000,
        other: 2000,
      },
    },
    savings: {
      recommended_monthly: 11000,
      actual_surplus: 15000,
      percentage: 27,
    },
    rule_50_30_20_comparison: {
      needs_ideal: 27500,
      wants_ideal: 16500,
      savings_ideal: 11000,
      status: 'Optimal',
    },
  },
  saving_suggestions: [
    {
      id: 'sug-1',
      title: 'Optimize Food & Dining Out',
      explanation: 'Your food expenditure is ₹7,000/mo. Shifting 2 restaurant meals to home-prepared culinary batch cooking can conserve up to 20% of this budget with zero lifestyle penalty.',
      potential_saving: '₹1,500/month',
      priority: 'High',
      category: 'Food',
    },
    {
      id: 'sug-2',
      title: 'Audit Digital & Lifestyle Subscriptions',
      explanation: 'Consolidate multiple streaming platforms and recurring unused trial memberships into annual plans or active rotation.',
      potential_saving: '₹800/month',
      priority: 'Medium',
      category: 'Entertainment',
    },
    {
      id: 'sug-3',
      title: 'Implement 48-Hour Shopping Rule',
      explanation: 'Pause online impulse purchases exceeding ₹1,500 for 48 hours to evaluate genuine necessity versus spontaneous dopamine triggers.',
      potential_saving: '₹1,200/month',
      priority: 'High',
      category: 'Shopping',
    },
    {
      id: 'sug-4',
      title: 'Automate Salary-Day Goal Sweep',
      explanation: 'Schedule an automatic recurring transfer of ₹12,000 directly into a dedicated high-yield liquid fund on the 1st of every month before discretionary spending begins.',
      potential_saving: '₹2,500/month',
      priority: 'High',
      category: 'Savings',
    },
  ],
  monthly_summary: {
    health_score: 'Strong',
    health_score_num: 82,
    overall_summary: 'Your financial structure shows healthy cash flow with a 27% savings rate (₹15,000 surplus per month). With ₹40,000 currently in reserve towards your ₹1,50,000 Emergency Fund, you are on pace to fulfill your safety net in approximately 7.3 months.',
    biggest_category: 'Housing (₹15,000)',
    savings_progress: '₹40,000 of ₹1,50,000 target reached (26.7% funded, ~7-8 months to target).',
    positive_observation: 'Maintained strong cash surplus exceeding the recommended 20% savings threshold without any high-interest debt burden.',
    area_to_improve: 'Housing constitutes 27% of net income while combined non-essential discretionary spending accounts for ₹9,000.',
    next_month_focus: 'Automate high-yield emergency deposits immediately upon salary receipt.',
  },
  insights: [
    {
      title: 'Emergency Runway',
      value: '1.0 month',
      description: 'Current liquid buffer covers 1 full month of living expenses; target is 3.75 months.',
    },
    {
      title: 'Savings Efficiency',
      value: '27%',
      description: 'Exceeds standard 20% baseline recommendation.',
    },
    {
      title: 'Discretionary Ratio',
      value: '16%',
      description: 'Well below 30% ceiling, preserving strong capital efficiency.',
    },
  ],
};
