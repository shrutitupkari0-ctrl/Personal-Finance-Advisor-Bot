import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  className?: string;
  onClick?: () => void;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showSubtitle = true,
  className = '',
  onClick,
}) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  };

  const textSizes = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2.5 select-none transition-all ${
        onClick ? 'cursor-pointer group' : ''
      } ${className}`}
    >
      {/* Brand Icon SVG */}
      <div className={`relative flex items-center justify-center shrink-0 ${iconSizes[size]}`}>
        <div className="absolute inset-0 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-emerald-400 opacity-90 blur-[2px] group-hover:opacity-100 transition-opacity" />
        <div className="relative w-full h-full rounded-xl bg-gradient-to-br from-slate-900 to-indigo-950 p-[1.5px] shadow-sm shadow-indigo-500/20">
          <div className="w-full h-full rounded-[10px] bg-slate-900/90 flex items-center justify-center overflow-hidden">
            <svg
              viewBox="0 0 36 36"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="w-4/5 h-4/5 transform group-hover:scale-105 transition-transform"
            >
              {/* Outer Growth Knot */}
              <path
                d="M18 4L30 11V25L18 32L6 25V11L18 4Z"
                stroke="url(#finwise-grad-1)"
                strokeWidth="2.2"
                strokeLinejoin="round"
              />
              {/* Upward Dynamic Growth Arrow / Trend Line */}
              <path
                d="M11 22L16 17L20 20L25 13"
                stroke="#34D399"
                strokeWidth="2.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* Arrow Head */}
              <path
                d="M21 13H25V17"
                stroke="#34D399"
                strokeWidth="2.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* AI Neural Spark Core */}
              <circle cx="18" cy="18" r="2.5" fill="#818CF8" />
              <defs>
                <linearGradient id="finwise-grad-1" x1="6" y1="4" x2="30" y2="32" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#6366F1" />
                  <stop offset="0.5" stopColor="#3B82F6" />
                  <stop offset="1" stopColor="#10B981" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>

      {/* Typography */}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 leading-none">
          <span className={`font-bold tracking-tight text-slate-900 dark:text-white ${textSizes[size]}`}>
            Vanguard
          </span>
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-black tracking-wide bg-gradient-to-r from-indigo-500 to-emerald-500 text-white shadow-xs">
            IQ
          </span>
        </div>
        {showSubtitle && (
          <span className="text-[10px] font-medium tracking-wider text-slate-500 dark:text-slate-400 uppercase mt-0.5">
            Personal Finance Advisor
          </span>
        )}
      </div>
    </div>
  );
};
