import React, { useState } from 'react';
import {
  CurrencySymbol,
  UserFinancialInput,
  ExpenseItem,
} from '../types/finance';
import {
  Wallet,
  Receipt,
  Target,
  ShieldCheck,
  Plus,
  Trash2,
  Sparkles,
  ArrowRight,
  Info,
  Calendar,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { DEMO_FINANCIAL_INPUT } from '../utils/demoData';

interface FinanceFormProps {
  initialData?: UserFinancialInput;
  currency: CurrencySymbol;
  onCurrencyChange: (c: CurrencySymbol) => void;
  onSubmit: (data: UserFinancialInput) => void;
  isLoading: boolean;
  onLoadDemo: () => void;
}

const PRESET_GOALS = [
  'Build an emergency fund',
  'Buy a laptop',
  'Higher education',
  'Vacation',
  'Buy a vehicle',
  'House down payment',
  'General savings',
];

export const FinanceForm: React.FC<FinanceFormProps> = ({
  initialData,
  currency,
  onCurrencyChange,
  onSubmit,
  isLoading,
  onLoadDemo,
}) => {
  const [income, setIncome] = useState<number>(initialData?.income || 50000);
  const [otherIncome, setOtherIncome] = useState<number>(initialData?.otherIncome || 5000);

  const [expenses, setExpenses] = useState<{ [key: string]: number }>({
    housing: initialData?.expenses?.housing ?? 15000,
    food: initialData?.expenses?.food ?? 7000,
    transportation: initialData?.expenses?.transportation ?? 4000,
    utilities: initialData?.expenses?.utilities ?? 3000,
    entertainment: initialData?.expenses?.entertainment ?? 3000,
    shopping: initialData?.expenses?.shopping ?? 4000,
    education: initialData?.expenses?.education ?? 0,
    healthcare: initialData?.expenses?.healthcare ?? 2000,
    other: initialData?.expenses?.other ?? 2000,
  });

  const [customExpenses, setCustomExpenses] = useState<ExpenseItem[]>(
    initialData?.customExpenses || []
  );

  const [newCustomName, setNewCustomName] = useState('');
  const [newCustomAmount, setNewCustomAmount] = useState<number | ''>('');
  const [newCustomCategory, setNewCustomCategory] = useState<'Needs' | 'Wants'>('Wants');

  const [financialGoal, setFinancialGoal] = useState<string>(
    initialData?.financialGoal || 'Build an emergency fund'
  );
  const [customGoalName, setCustomGoalName] = useState<string>('');
  const [targetAmount, setTargetAmount] = useState<number>(initialData?.targetAmount || 150000);
  const [targetDate, setTargetDate] = useState<string>(initialData?.targetDate || '12 months');
  const [currentSavings, setCurrentSavings] = useState<number>(initialData?.currentSavings || 40000);

  const [riskPreference, setRiskPreference] = useState<'Conservative' | 'Balanced' | 'Aggressive'>(
    initialData?.riskPreference || 'Balanced'
  );
  const [notes, setNotes] = useState<string>(initialData?.notes || '');

  // Calculate live totals
  const totalBaseExpenses = Object.values(expenses).reduce((acc, val) => acc + (Number(val) || 0), 0);
  const totalCustomExpenses = customExpenses.reduce((acc, item) => acc + (Number(item.amount) || 0), 0);
  const totalExpenses = totalBaseExpenses + totalCustomExpenses;
  const totalIncome = (Number(income) || 0) + (Number(otherIncome) || 0);
  const netSurplus = totalIncome - totalExpenses;

  const handleExpenseChange = (key: string, value: string) => {
    const num = parseFloat(value);
    setExpenses((prev) => ({
      ...prev,
      [key]: isNaN(num) ? 0 : num,
    }));
  };

  const handleAddCustomExpense = () => {
    if (!newCustomName.trim() || !newCustomAmount || Number(newCustomAmount) <= 0) return;
    const newItem: ExpenseItem = {
      id: `custom-${Date.now()}`,
      name: newCustomName.trim(),
      amount: Number(newCustomAmount),
      category: newCustomCategory,
    };
    setCustomExpenses((prev) => [...prev, newItem]);
    setNewCustomName('');
    setNewCustomAmount('');
  };

  const handleRemoveCustomExpense = (id: string) => {
    setCustomExpenses((prev) => prev.filter((item) => item.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const effectiveGoal = financialGoal === 'Custom' ? customGoalName.trim() || 'General savings' : financialGoal;

    const mergedExpenses = { ...expenses };
    customExpenses.forEach((item) => {
      mergedExpenses[`custom_${item.name.toLowerCase().replace(/\s+/g, '_')}`] = item.amount;
    });

    const payload: UserFinancialInput = {
      income: Number(income) || 0,
      otherIncome: Number(otherIncome) || 0,
      currency,
      expenses: mergedExpenses as any,
      customExpenses,
      financialGoal: effectiveGoal,
      targetAmount: Number(targetAmount) || 0,
      targetDate,
      currentSavings: Number(currentSavings) || 0,
      riskPreference,
      notes,
    };

    onSubmit(payload);
  };

  return (
    <div className="max-w-4xl mx-auto py-6 sm:py-8 space-y-8">
      {/* Form Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Personal Financial Assessment
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Provide your monthly inflow, outgoings, and savings targets for AI synthesis.
          </p>
        </div>

        <button
          type="button"
          onClick={onLoadDemo}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 transition shadow-xs self-start sm:self-auto"
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
          <span>Fill with Realistic Demo Data</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-10">
        {/* SECTION 1: INCOME */}
        <section className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Section 1: Monthly Income
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Your regular primary salary and secondary earnings.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Monthly Primary Income ({currency})
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
                  {currency}
                </span>
                <input
                  type="number"
                  required
                  min="0"
                  step="500"
                  value={income || ''}
                  onChange={(e) => setIncome(parseFloat(e.target.value) || 0)}
                  placeholder="50000"
                  className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm font-medium"
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Net take-home pay</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Other Monthly Income ({currency})
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
                  {currency}
                </span>
                <input
                  type="number"
                  min="0"
                  step="500"
                  value={otherIncome || ''}
                  onChange={(e) => setOtherIncome(parseFloat(e.target.value) || 0)}
                  placeholder="5000"
                  className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm font-medium"
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Freelance, dividends, bonus</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Currency Selector
              </label>
              <select
                value={currency}
                onChange={(e) => onCurrencyChange(e.target.value as CurrencySymbol)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm font-medium"
              >
                <option value="₹">INR (₹) - Indian Rupee</option>
                <option value="$">USD ($) - US Dollar</option>
                <option value="€">EUR (€) - Euro</option>
                <option value="£">GBP (£) - British Pound</option>
                <option value="¥">JPY (¥) - Japanese Yen</option>
              </select>
              <span className="text-[11px] text-slate-400 mt-1 block">Applied across all reports</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-600 dark:text-slate-400">Total Net Inflow:</span>
            <span className="font-bold text-sm text-indigo-600 dark:text-indigo-400">
              {currency}{totalIncome.toLocaleString()}
            </span>
          </div>
        </section>

        {/* SECTION 2: MONTHLY EXPENSES */}
        <section className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Section 2: Monthly Expenses
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Itemize living essentials, lifestyle, and discretionary commitments.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
            {[
              { key: 'housing', label: 'Rent / Housing', placeholder: '15000', tag: 'Needs' },
              { key: 'food', label: 'Food & Groceries', placeholder: '7000', tag: 'Needs' },
              { key: 'transportation', label: 'Transportation & Fuel', placeholder: '4000', tag: 'Needs' },
              { key: 'utilities', label: 'Utilities & Internet', placeholder: '3000', tag: 'Needs' },
              { key: 'healthcare', label: 'Healthcare & Medical', placeholder: '2000', tag: 'Needs' },
              { key: 'education', label: 'Education & Courses', placeholder: '0', tag: 'Needs' },
              { key: 'entertainment', label: 'Entertainment & Outings', placeholder: '3000', tag: 'Wants' },
              { key: 'shopping', label: 'Shopping & Discretionary', placeholder: '4000', tag: 'Wants' },
              { key: 'other', label: 'Other Miscellaneous', placeholder: '2000', tag: 'Wants' },
            ].map((field) => (
              <div key={field.key} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-semibold text-slate-700 dark:text-slate-300">
                    {field.label}
                  </label>
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      field.tag === 'Needs'
                        ? 'bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400'
                        : 'bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    {field.tag}
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">
                    {currency}
                  </span>
                  <input
                    type="number"
                    min="0"
                    step="100"
                    value={expenses[field.key] ?? ''}
                    onChange={(e) => handleExpenseChange(field.key, e.target.value)}
                    placeholder={field.placeholder}
                    className="w-full pl-7 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Dynamic Custom Expenses (+ Add Expense) */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Custom Expense Lines
              </span>
              <span className="text-xs text-slate-400">
                {customExpenses.length} additional item{customExpenses.length === 1 ? '' : 's'}
              </span>
            </div>

            {/* List of Custom Expenses */}
            {customExpenses.length > 0 && (
              <div className="space-y-2">
                {customExpenses.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                        {item.name}
                      </span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                        {item.category}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-slate-900 dark:text-white">
                        {currency}{item.amount.toLocaleString()}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveCustomExpense(item.id)}
                        className="p-1 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Add Custom Expense Row */}
            <div className="flex flex-col sm:flex-row items-center gap-3 p-3.5 rounded-xl bg-slate-100/60 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700">
              <input
                type="text"
                value={newCustomName}
                onChange={(e) => setNewCustomName(e.target.value)}
                placeholder="Expense Name (e.g. Pet Care, Gadgets)"
                className="w-full sm:flex-1 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
              />
              <div className="relative w-full sm:w-36">
                <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">
                  {currency}
                </span>
                <input
                  type="number"
                  min="0"
                  value={newCustomAmount}
                  onChange={(e) =>
                    setNewCustomAmount(e.target.value ? parseFloat(e.target.value) : '')
                  }
                  placeholder="Amount"
                  className="w-full pl-6 pr-2 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
              </div>
              <select
                value={newCustomCategory}
                onChange={(e) => setNewCustomCategory(e.target.value as 'Needs' | 'Wants')}
                className="w-full sm:w-28 px-2 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
              >
                <option value="Wants">Wants</option>
                <option value="Needs">Needs</option>
              </select>
              <button
                type="button"
                onClick={handleAddCustomExpense}
                disabled={!newCustomName.trim() || !newCustomAmount}
                className="w-full sm:w-auto px-4 py-2 rounded-lg font-bold text-xs bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 disabled:opacity-50 transition flex items-center justify-center gap-1.5 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Expense</span>
              </button>
            </div>
          </div>

          {/* Running Outgoings Summary Bar */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div>
              <span className="text-slate-500 dark:text-slate-400">Total Monthly Expenses:</span>{' '}
              <span className="font-bold text-sm text-rose-600 dark:text-rose-400 ml-1">
                {currency}{totalExpenses.toLocaleString()}
              </span>
            </div>
            <div>
              <span className="text-slate-500 dark:text-slate-400">Estimated Surplus / Deficit:</span>{' '}
              <span
                className={`font-bold text-sm ml-1 ${
                  netSurplus >= 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {currency}{netSurplus.toLocaleString()}/mo
              </span>
            </div>
          </div>
        </section>

        {/* SECTION 3: FINANCIAL GOALS */}
        <section className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Section 3: Financial Goals & Current Reserve
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Define the anchor objective your financial plan optimizes for.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Primary Financial Goal
              </label>
              <select
                value={PRESET_GOALS.includes(financialGoal) ? financialGoal : 'Custom'}
                onChange={(e) => {
                  if (e.target.value === 'Custom') {
                    setFinancialGoal('Custom');
                  } else {
                    setFinancialGoal(e.target.value);
                  }
                }}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm"
              >
                {PRESET_GOALS.map((goal) => (
                  <option key={goal} value={goal}>
                    {goal}
                  </option>
                ))}
                <option value="Custom">+ Other Custom Goal</option>
              </select>

              {financialGoal === 'Custom' && (
                <input
                  type="text"
                  value={customGoalName}
                  onChange={(e) => setCustomGoalName(e.target.value)}
                  placeholder="Enter your custom goal name..."
                  className="mt-2 w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                />
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Target Amount ({currency})
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
                  {currency}
                </span>
                <input
                  type="number"
                  min="1000"
                  step="5000"
                  value={targetAmount || ''}
                  onChange={(e) => setTargetAmount(parseFloat(e.target.value) || 0)}
                  placeholder="150000"
                  className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Target Horizon / Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input
                  type="text"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  placeholder="e.g. 12 months, Dec 2027"
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Current Existing Savings ({currency})
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
                  {currency}
                </span>
                <input
                  type="number"
                  min="0"
                  step="1000"
                  value={currentSavings || ''}
                  onChange={(e) => setCurrentSavings(parseFloat(e.target.value) || 0)}
                  placeholder="40000"
                  className="w-full pl-8 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm font-medium"
                />
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 4: RISK PREFERENCE & NOTES */}
        <section className="p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Section 4: Risk Profile & Notes
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Calibrate aggressiveness and provide any unique situational context.
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-3">
              Risk Preference
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                {
                  id: 'Conservative',
                  title: 'Conservative',
                  desc: 'Focus on high liquid reserves, debt prevention, and low volatility.',
                },
                {
                  id: 'Balanced',
                  title: 'Balanced',
                  desc: 'Blend steady cash reserves with disciplined 50/30/20 growth.',
                },
                {
                  id: 'Aggressive',
                  title: 'Aggressive',
                  desc: 'Accelerated goal attainment with lean discretionary lifestyle cutbacks.',
                },
              ].map((tier) => (
                <div
                  key={tier.id}
                  onClick={() => setRiskPreference(tier.id as any)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    riskPreference === tier.id
                      ? 'border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 dark:border-indigo-500 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">
                      {tier.title}
                    </span>
                    <input
                      type="radio"
                      name="risk"
                      checked={riskPreference === tier.id}
                      onChange={() => setRiskPreference(tier.id as any)}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    {tier.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Optional Context & Notes
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Planning wedding next winter, freelance contract ending in 4 months, paying off student loan..."
              className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden text-sm"
            />
          </div>
        </section>

        {/* Submit Actions */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Info className="w-4 h-4 text-slate-400 shrink-0" />
            <span>AI generates instant 50/30/20 plan, suggestions, and summary.</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={onLoadDemo}
              className="w-full sm:w-auto px-5 py-3 rounded-xl font-semibold text-xs sm:text-sm bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            >
              Demo Values
            </button>
            <button
              type="submit"
              disabled={isLoading || totalIncome <= 0}
              className="w-full sm:w-auto px-8 py-3 rounded-xl font-bold text-sm bg-gradient-to-r from-indigo-600 to-emerald-600 hover:from-indigo-700 hover:to-emerald-700 text-white shadow-lg shadow-indigo-600/30 disabled:opacity-50 transition-all flex items-center justify-center gap-2 transform active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-emerald-300" />
              <span>{isLoading ? 'Synthesizing...' : 'Generate My Financial Plan'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
