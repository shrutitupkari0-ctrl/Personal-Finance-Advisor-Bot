import React from 'react';
import {
  LayoutDashboard,
  PieChart,
  PiggyBank,
  Sparkles,
  SlidersHorizontal,
  FileSpreadsheet,
  X,
  ChevronRight,
  ShieldAlert,
  Info,
} from 'lucide-react';
import { Logo } from './Logo';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  isOpen: boolean;
  onClose: () => void;
  hasPlan: boolean;
  healthScore?: string;
  healthScoreNum?: number;
  availableBalance?: number;
  currency: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpen,
  onClose,
  hasPlan,
  healthScore,
  healthScoreNum,
  availableBalance,
  currency,
}) => {
  const navItems = [
    {
      id: 'landing',
      label: 'Home & Features',
      icon: Info,
      badge: null,
      alwaysAvailable: true,
    },
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: hasPlan ? 'Active' : null,
      requiresPlan: true,
    },
    {
      id: 'budget',
      label: 'Budget Plan',
      icon: PieChart,
      badge: '50/30/20',
      requiresPlan: true,
    },
    {
      id: 'savings',
      label: 'Saving Suggestions',
      icon: PiggyBank,
      badge: hasPlan ? 'AI Picks' : null,
      requiresPlan: true,
    },
    {
      id: 'what-if',
      label: 'What-If Simulator',
      icon: SlidersHorizontal,
      badge: 'Simulate',
      requiresPlan: true,
    },
    {
      id: 'advisor',
      label: 'Ask VanguardIQ',
      icon: Sparkles,
      badge: 'Live',
      requiresPlan: true,
    },
    {
      id: 'form',
      label: hasPlan ? 'Edit Financial Data' : 'Create Financial Plan',
      icon: FileSpreadsheet,
      badge: null,
      alwaysAvailable: true,
    },
  ];

  const handleNavClick = (id: string, requiresPlan?: boolean) => {
    if (requiresPlan && !hasPlan) {
      onSelectTab('form');
    } else {
      onSelectTab(id);
    }
    onClose();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        } lg:static lg:z-30 lg:shadow-none shrink-0`}
      >
        {/* Top Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <Logo size="sm" onClick={() => handleNavClick('landing')} />
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Financial Status Quick Card if Plan Active */}
        {hasPlan && (
          <div className="mx-4 my-3 p-3.5 rounded-xl bg-gradient-to-br from-indigo-50/80 to-blue-50/50 dark:from-indigo-950/30 dark:to-slate-800/40 border border-indigo-100 dark:border-indigo-900/40">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px]">
                Health Score
              </span>
              <span
                className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                  healthScore === 'Strong'
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                    : healthScore === 'Moderate'
                    ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                    : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                }`}
              >
                {healthScore || 'Optimal'} {healthScoreNum ? `(${healthScoreNum}/100)` : ''}
              </span>
            </div>
            {availableBalance !== undefined && (
              <div className="mt-1 flex items-baseline justify-between">
                <span className="text-xs text-slate-600 dark:text-slate-400">Monthly Surplus</span>
                <span className="text-sm font-bold text-slate-900 dark:text-white">
                  {currency}
                  {availableBalance.toLocaleString()}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
          <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            Menu
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            const isLocked = item.requiresPlan && !hasPlan;

            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id, item.requiresPlan)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                    : isLocked
                    ? 'text-slate-400 dark:text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/40 opacity-70'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 ${
                      isActive
                        ? 'text-white'
                        : isLocked
                        ? 'text-slate-400 dark:text-slate-600'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.badge && (
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {isActive && <ChevronRight className="w-4 h-4 text-white/80" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer / Educational Disclaimer Notice */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 dark:text-slate-500 space-y-2">
          <div className="flex items-start gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
            <p className="leading-tight">
              VanguardIQ offers educational planning models; not certified investment advice.
            </p>
          </div>
          <div className="text-[10px] text-slate-400/80">v1.0 • Powered by Gemini 3.8 Flash</div>
        </div>
      </aside>
    </>
  );
};
