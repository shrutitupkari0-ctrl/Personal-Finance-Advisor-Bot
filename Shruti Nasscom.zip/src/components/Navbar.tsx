import React, { useState, useRef, useEffect } from 'react';
import { Logo } from './Logo';
import { CurrencySymbol } from '../types/finance';
import {
  Sun,
  Moon,
  Sparkles,
  ChevronDown,
  Menu,
  X,
  PlusCircle,
  BarChart3,
  HelpCircle,
  RotateCcw,
  ShieldCheck,
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  currency: CurrencySymbol;
  onCurrencyChange: (c: CurrencySymbol) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onTryDemo: () => void;
  onNewPlan: () => void;
  onToggleSidebar: () => void;
  hasPlan: boolean;
}

const CURRENCIES: { symbol: CurrencySymbol; label: string; name: string }[] = [
  { symbol: '₹', label: 'INR (₹)', name: 'Indian Rupee' },
  { symbol: '$', label: 'USD ($)', name: 'US Dollar' },
  { symbol: '€', label: 'EUR (€)', name: 'Euro' },
  { symbol: '£', label: 'GBP (£)', name: 'British Pound' },
  { symbol: '¥', label: 'JPY (¥)', name: 'Japanese Yen' },
];

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  currency,
  onCurrencyChange,
  isDarkMode,
  onToggleDarkMode,
  onTryDemo,
  onNewPlan,
  onToggleSidebar,
  hasPlan,
}) => {
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);
  const [quickMenuOpen, setQuickMenuOpen] = useState(false);
  const currencyRef = useRef<HTMLDivElement>(null);
  const quickMenuRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (currencyRef.current && !currencyRef.current.contains(event.target as Node)) {
        setCurrencyDropdownOpen(false);
      }
      if (quickMenuRef.current && !quickMenuRef.current.contains(event.target as Node)) {
        setQuickMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-white/90 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left Section: Mobile Menu + Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            type="button"
            className="lg:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            aria-label="Toggle navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <Logo onClick={() => onSelectTab('landing')} size="md" />
        </div>

        {/* Center Navigation for Tablet/Desktop */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-100/70 dark:bg-slate-800/70 p-1 rounded-xl border border-slate-200/50 dark:border-slate-700/50 text-sm font-medium">
          <button
            onClick={() => onSelectTab('landing')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              currentTab === 'landing'
                ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Overview
          </button>
          {hasPlan && (
            <>
              <button
                onClick={() => onSelectTab('dashboard')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  currentTab === 'dashboard'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => onSelectTab('budget')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  currentTab === 'budget'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Budget Plan
              </button>
              <button
                onClick={() => onSelectTab('savings')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  currentTab === 'savings'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                AI Suggestions
              </button>
              <button
                onClick={() => onSelectTab('what-if')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  currentTab === 'what-if'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                What-If?
              </button>
              <button
                onClick={() => onSelectTab('advisor')}
                className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                  currentTab === 'advisor'
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                Ask AI
              </button>
            </>
          )}
        </nav>

        {/* Right Section: Currency, Theme Toggle, Demo Button, Quick Menu */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Currency Dropdown */}
          <div className="relative" ref={currencyRef}>
            <button
              onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition border border-slate-200 dark:border-slate-700"
              title="Select Currency"
            >
              <span>{currency}</span>
              <span className="hidden sm:inline">
                {CURRENCIES.find((c) => c.symbol === currency)?.label.split(' ')[0]}
              </span>
              <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>

            {currencyDropdownOpen && (
              <div className="absolute right-0 mt-2 w-44 rounded-xl bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Select Currency
                </div>
                {CURRENCIES.map((c) => (
                  <button
                    key={c.symbol}
                    onClick={() => {
                      onCurrencyChange(c.symbol);
                      setCurrencyDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition ${
                      currency === c.symbol
                        ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-bold'
                        : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                  >
                    <span>{c.label}</span>
                    <span className="text-[11px] text-slate-400">{c.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Day / Night Theme Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition"
            aria-label="Toggle day/night mode"
            title={isDarkMode ? 'Switch to Day Mode' : 'Switch to Night Mode'}
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 text-amber-400 hover:rotate-45 transition-transform duration-300" />
            ) : (
              <Moon className="w-4 h-4 text-slate-700 hover:-rotate-12 transition-transform duration-300" />
            )}
          </button>

          {/* Try Demo Button */}
          <button
            onClick={onTryDemo}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 transition shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
            <span>Try Demo</span>
          </button>

          {/* Quick Actions Dropdown */}
          <div className="relative" ref={quickMenuRef}>
            <button
              onClick={() => setQuickMenuOpen(!quickMenuOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm shadow-indigo-600/20 transition active:scale-95"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{hasPlan ? 'Edit Plan' : 'Get Started'}</span>
              <ChevronDown className="w-3 h-3 opacity-80" />
            </button>

            {quickMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Quick Actions
                </div>
                <button
                  onClick={() => {
                    onNewPlan();
                    setQuickMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                >
                  <PlusCircle className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>{hasPlan ? 'Re-run Financial Assessment' : 'Create New Financial Plan'}</span>
                </button>
                <button
                  onClick={() => {
                    onTryDemo();
                    setQuickMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>Load Sample Demo Data</span>
                </button>
                {hasPlan && (
                  <>
                    <div className="border-t border-slate-100 dark:border-slate-700 my-1" />
                    <button
                      onClick={() => {
                        onSelectTab('what-if');
                        setQuickMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                    >
                      <BarChart3 className="w-4 h-4 text-blue-500" />
                      <span>Simulate 'What If' Scenarios</span>
                    </button>
                  </>
                )}
                <div className="border-t border-slate-100 dark:border-slate-700 my-1" />
                <div className="px-3 py-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span>Private & encrypted in-session</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
