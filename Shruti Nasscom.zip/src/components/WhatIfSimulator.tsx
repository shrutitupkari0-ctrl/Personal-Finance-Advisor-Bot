import React, { useState, useMemo } from 'react';
import { CurrencySymbol } from '../types/finance';
import {
  SlidersHorizontal,
  TrendingUp,
  Clock,
  Zap,
  Sparkles,
  ArrowRight,
  RotateCcw,
  CheckCircle,
  HelpCircle,
  AlertCircle,
  Info,
} from 'lucide-react';

interface WhatIfSimulatorProps {
  initialIncome: number;
  initialExpenses: number;
  currency: CurrencySymbol;
  targetGoal: string;
  targetAmount: number;
  currentSavings: number;
}

export const WhatIfSimulator: React.FC<WhatIfSimulatorProps> = ({
  initialIncome,
  initialExpenses,
  currency,
  targetGoal,
  targetAmount,
  currentSavings,
}) => {
  // Baseline values
  const baseSurplus = Math.max(0, initialIncome - initialExpenses);
  const baseMonthsToGoal =
    baseSurplus > 0
      ? Math.ceil(Math.max(0, targetAmount - currentSavings) / baseSurplus)
      : 99;

  // Simulator State
  const [simIncome, setSimIncome] = useState<number>(initialIncome);
  const [simExpenses, setSimExpenses] = useState<number>(initialExpenses);
  const [additionalSavings, setAdditionalSavings] = useState<number>(0);

  // Computed values
  const simBalance = simIncome - simExpenses;
  const totalSimMonthlySavings = Math.max(0, simBalance + additionalSavings);
  const simSavingsRate =
    simIncome > 0 ? Math.round((totalSimMonthlySavings / simIncome) * 100) : 0;

  const remainingGap = Math.max(0, targetAmount - currentSavings);
  const simMonthsToGoal =
    totalSimMonthlySavings > 0
      ? Math.ceil(remainingGap / totalSimMonthlySavings)
      : 999;

  // Month delta calculation
  const monthsDifference = baseMonthsToGoal - simMonthsToGoal;

  const handleReset = () => {
    setSimIncome(initialIncome);
    setSimExpenses(initialExpenses);
    setAdditionalSavings(0);
  };

  return (
    <div className="space-y-8 py-4 sm:py-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              What-If Scenario Simulator
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300">
              Interactive
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Experiment with income increments, spending trimmings, or savings adjustments to see milestone acceleration.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center gap-1.5 self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Baseline</span>
        </button>
      </div>

      {/* Dynamic Impact Showcase Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-indigo-900 via-slate-900 to-slate-950 text-white border border-indigo-900/60 shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
          <Zap className="w-4 h-4" />
          <span>Simulation Outcome</span>
        </div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-black">
              {monthsDifference > 0 ? (
                <span className="text-emerald-400">
                  Reach your goal ~{monthsDifference} month{monthsDifference === 1 ? '' : 's'} earlier!
                </span>
              ) : monthsDifference < 0 ? (
                <span className="text-amber-400">
                  Reach your goal ~{Math.abs(monthsDifference)} month{Math.abs(monthsDifference) === 1 ? '' : 's'} later.
                </span>
              ) : (
                <span>Same timeline as current baseline.</span>
              )}
            </h2>
            <p className="text-xs text-slate-400">
              Target: <strong className="text-white">{targetGoal}</strong> ({currency}{targetAmount.toLocaleString()})
            </p>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-center">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Baseline Pace
              </span>
              <span className="text-lg font-bold text-slate-300">
                ~{baseMonthsToGoal} mos
              </span>
            </div>
            <ArrowRight className="w-5 h-5 text-indigo-400" />
            <div className="text-center p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10">
              <span className="text-[10px] text-emerald-400 uppercase tracking-wider block font-bold">
                Simulated Pace
              </span>
              <span className="text-xl font-black text-white">
                ~{simMonthsToGoal} mos
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Simulator Inputs & Metric Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sliders Form Panel (7 cols) */}
        <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
            <span>Simulate Financial Levers</span>
          </h3>

          {/* Slider 1: Monthly Income */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Monthly Income ({currency})
              </label>
              <span className="font-bold text-sm text-indigo-600 dark:text-indigo-400">
                {currency}{simIncome.toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min={Math.max(10000, initialIncome * 0.5)}
              max={initialIncome * 2.5}
              step="1000"
              value={simIncome}
              onChange={(e) => setSimIncome(Number(e.target.value))}
              className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>{currency}{(initialIncome * 0.5).toLocaleString()}</span>
              <span>Baseline: {currency}{initialIncome.toLocaleString()}</span>
              <span>{currency}{(initialIncome * 2.5).toLocaleString()}</span>
            </div>
          </div>

          {/* Slider 2: Monthly Expenses */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Monthly Expenses ({currency})
              </label>
              <span className="font-bold text-sm text-rose-600 dark:text-rose-400">
                {currency}{simExpenses.toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min={Math.max(5000, initialExpenses * 0.4)}
              max={initialExpenses * 1.8}
              step="500"
              value={simExpenses}
              onChange={(e) => setSimExpenses(Number(e.target.value))}
              className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-rose-600"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>{currency}{(initialExpenses * 0.4).toLocaleString()}</span>
              <span>Baseline: {currency}{initialExpenses.toLocaleString()}</span>
              <span>{currency}{(initialExpenses * 1.8).toLocaleString()}</span>
            </div>
          </div>

          {/* Slider 3: Additional Dedicated Monthly Savings */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Dedicated Extra Monthly Savings ({currency})
              </label>
              <span className="font-bold text-sm text-emerald-600 dark:text-emerald-400">
                +{currency}{additionalSavings.toLocaleString()}/mo
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="25000"
              step="500"
              value={additionalSavings}
              onChange={(e) => setAdditionalSavings(Number(e.target.value))}
              className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>+0</span>
              <span>+₹10,000</span>
              <span>+₹25,000</span>
            </div>
          </div>

          {/* Preset Buttons for Quick Scenarios */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Quick Experiment Scenarios
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  setSimExpenses(Math.round(initialExpenses * 0.85));
                  setAdditionalSavings(2500);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition"
              >
                15% Expense Trim
              </button>
              <button
                type="button"
                onClick={() => {
                  setSimIncome(Math.round(initialIncome * 1.15));
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition"
              >
                15% Income Hike
              </button>
              <button
                type="button"
                onClick={() => {
                  setAdditionalSavings(5000);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition"
              >
                +₹5,000 Dedicated Save
              </button>
            </div>
          </div>
        </div>

        {/* Results Panel (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Simulated Metrics
            </h3>

            {/* Metric 1: New Available Balance */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                New Available Balance
              </span>
              <div
                className={`text-2xl font-black ${
                  simBalance >= 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {currency}{simBalance.toLocaleString()}/mo
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Baseline was {currency}{baseSurplus.toLocaleString()}/mo
              </span>
            </div>

            {/* Metric 2: New Savings Rate */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                New Savings Rate
              </span>
              <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">
                {simSavingsRate}%
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {simSavingsRate >= 20
                  ? 'Exceeds standard 50/30/20 target'
                  : 'Below recommended 20% target'}
              </span>
            </div>

            {/* Metric 3: Time to Goal */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Estimated Time to Complete Goal
              </span>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                ~{simMonthsToGoal} Months
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Gap to fill: {currency}{remainingGap.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Mandatory Estimate Disclaimer */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex items-start gap-2.5 text-xs text-slate-500 dark:text-slate-400">
            <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              *Calculations are simplified linear projections for educational planning and do not account for inflation, unexpected emergencies, or tax adjustments.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
