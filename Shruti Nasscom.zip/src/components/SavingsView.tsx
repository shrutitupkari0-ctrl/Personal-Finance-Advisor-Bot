import React, { useState } from 'react';
import { SavingSuggestion, CurrencySymbol } from '../types/finance';
import {
  Sparkles,
  PiggyBank,
  CheckCircle2,
  AlertCircle,
  Tag,
  ArrowRight,
  TrendingUp,
  Info,
  Sliders,
  DollarSign,
  Clock,
  ShieldCheck,
} from 'lucide-react';

interface SavingsViewProps {
  suggestions: SavingSuggestion[];
  currency: CurrencySymbol;
  financialGoal: string;
  targetAmount: number;
  currentSavings: number;
  monthlySurplus: number;
  onNavigateToSimulator: () => void;
}

export const SavingsView: React.FC<SavingsViewProps> = ({
  suggestions,
  currency,
  financialGoal,
  targetAmount,
  currentSavings,
  monthlySurplus,
  onNavigateToSimulator,
}) => {
  const [appliedSuggestions, setAppliedSuggestions] = useState<string[]>([]);

  const toggleApplySuggestion = (id: string) => {
    setAppliedSuggestions((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const remainingGap = Math.max(0, targetAmount - currentSavings);
  const monthlyPace = monthlySurplus > 0 ? monthlySurplus : 2500;
  const projectedMonths = Math.ceil(remainingGap / monthlyPace);
  const progressPct = Math.min(100, Math.round((currentSavings / (targetAmount || 1)) * 100));

  return (
    <div className="space-y-8 py-4 sm:py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              AI Saving Suggestions & Goal Hub
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300">
              Personalized
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Data-backed tactical opportunities prioritized by return on lifestyle effort.
          </p>
        </div>

        <button
          onClick={onNavigateToSimulator}
          className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition active:scale-95 flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Test in 'What If' Simulator</span>
        </button>
      </div>

      {/* Goal Summary Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 text-white border border-indigo-900/50 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
              <PiggyBank className="w-4 h-4" />
              <span>Target Objective</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black">{financialGoal}</h2>
            <p className="text-xs text-slate-400">
              Projected milestone completion: ~{projectedMonths} months at current saving rate
            </p>
          </div>

          <div className="flex items-baseline gap-3 text-left md:text-right">
            <div>
              <span className="text-xs text-slate-400 block">Accumulated Savings</span>
              <span className="text-2xl font-black text-emerald-400">
                {currency}{currentSavings.toLocaleString()}
              </span>
            </div>
            <div className="text-slate-500 text-xl font-light">/</div>
            <div>
              <span className="text-xs text-slate-400 block">Target Needed</span>
              <span className="text-xl font-bold text-slate-200">
                {currency}{targetAmount.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Dynamic Progress Bar */}
        <div className="space-y-2">
          <div className="h-3.5 w-full bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 transition-all duration-700"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-slate-400 font-medium">
            <span>{progressPct}% Funded</span>
            <span>{currency}{remainingGap.toLocaleString()} Remaining to Target</span>
          </div>
        </div>
      </div>

      {/* AI Saving Suggestions Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Tactical Savings Levers
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            {suggestions.length} AI Recommendations
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {suggestions.map((sug, index) => {
            const isApplied = appliedSuggestions.includes(sug.id || `sug-${index}`);
            return (
              <div
                key={sug.id || index}
                className={`p-6 rounded-2xl border transition-all ${
                  isApplied
                    ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-700 shadow-sm'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs hover:border-indigo-300 dark:hover:border-indigo-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                        sug.priority === 'High'
                          ? 'bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300'
                          : sug.priority === 'Medium'
                          ? 'bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300'
                          : 'bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300'
                      }`}
                    >
                      {sug.priority} Priority
                    </span>
                    {sug.category && (
                      <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <Tag className="w-3 h-3 text-slate-400" />
                        <span>{sug.category}</span>
                      </span>
                    )}
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                      Estimated Saving
                    </span>
                    <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                      {sug.potential_saving}
                    </span>
                  </div>
                </div>

                <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                  {sug.title}
                </h4>

                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                  {sug.explanation}
                </p>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 italic">
                    *Estimated impact based on spending patterns
                  </span>

                  <button
                    onClick={() => toggleApplySuggestion(sug.id || `sug-${index}`)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      isApplied
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isApplied ? 'Target Tracked' : 'Track Lever'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Disclaimer Box */}
      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-start gap-3 text-xs text-slate-500 dark:text-slate-400">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          Savings potentials are simulated models derived from historical peer statistics and lifestyle averages. These do not represent guaranteed cash balances or commercial commitments.
        </p>
      </div>
    </div>
  );
};
