import React from 'react';
import { BudgetPlan, CurrencySymbol } from '../types/finance';
import {
  PieChart as PieIcon,
  CheckCircle,
  HelpCircle,
  ArrowRight,
  TrendingUp,
  Shield,
  Coffee,
  Sparkles,
  Info,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';

interface BudgetPlanViewProps {
  budgetPlan: BudgetPlan;
  currency: CurrencySymbol;
  financialGoal: string;
  targetAmount: number;
  currentSavings: number;
  onNavigateToSimulator: () => void;
}

const BUDGET_RULE_COLORS = {
  needs: '#3B82F6', // Blue
  wants: '#F59E0B', // Amber
  savings: '#10B981', // Emerald
};

export const BudgetPlanView: React.FC<BudgetPlanViewProps> = ({
  budgetPlan,
  currency,
  financialGoal,
  targetAmount,
  currentSavings,
  onNavigateToSimulator,
}) => {
  const { total_income, needs, wants, savings, rule_50_30_20_comparison } = budgetPlan;

  const chartData = [
    { name: 'Needs (Essentials)', value: needs.total, color: BUDGET_RULE_COLORS.needs },
    { name: 'Wants (Discretionary)', value: wants.total, color: BUDGET_RULE_COLORS.wants },
    { name: 'Savings (Reserve)', value: Math.max(0, savings.actual_surplus), color: BUDGET_RULE_COLORS.savings },
  ];

  const goalPct = Math.min(100, Math.round((currentSavings / (targetAmount || 1)) * 100));

  return (
    <div className="space-y-8 py-4 sm:py-6">
      {/* Title & Introduction */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              My Budget Plan
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300">
              50/30/20 Standard
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Categorical analysis of Needs, Wants, and Savings compared against financial best-practice benchmarks.
          </p>
        </div>

        <button
          onClick={onNavigateToSimulator}
          className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition active:scale-95 flex items-center gap-1.5 self-start sm:self-auto"
        >
          <span>Simulate Budget Shifts</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Donut Chart & 50/30/20 Comparison Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Donut Chart Representation */}
        <div className="lg:col-span-6 p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-indigo-600" />
              <span>Needs vs Wants vs Savings</span>
            </h3>
            <span className="text-xs text-slate-400">Monthly Inflow: {currency}{total_income.toLocaleString()}</span>
          </div>

          <div className="h-64 w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={95}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${currency}${Number(val).toLocaleString()}`, 'Amount']}
                  contentStyle={{
                    backgroundColor: '#1E293B',
                    borderRadius: '8px',
                    border: 'none',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>

            {/* Center Label in Donut */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-xs font-semibold text-slate-400">Total Inflow</span>
              <span className="text-lg font-black text-slate-900 dark:text-white">
                {currency}{total_income.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Three Bottom Distribution Cards */}
          <div className="grid grid-cols-3 gap-3 pt-4 border-t border-slate-100 dark:border-slate-800 text-center">
            <div className="p-2.5 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40">
              <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider block">
                Needs ({needs.percentage}%)
              </span>
              <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {currency}{needs.total.toLocaleString()}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/40">
              <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider block">
                Wants ({wants.percentage}%)
              </span>
              <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {currency}{wants.total.toLocaleString()}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40">
              <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">
                Savings ({savings.percentage}%)
              </span>
              <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                {currency}{savings.actual_surplus.toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Right: 50/30/20 Benchmark Comparison */}
        <div className="lg:col-span-6 p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              50/30/20 Ideal vs Actual Rule
            </h3>
            <span
              className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                rule_50_30_20_comparison.status === 'Optimal'
                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300'
                  : 'bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-300'
              }`}
            >
              Status: {rule_50_30_20_comparison.status}
            </span>
          </div>

          <div className="space-y-4">
            {/* Needs Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-blue-500" />
                  <span>Needs (Ideal: 50% max)</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  Actual: {needs.percentage}% ({currency}{needs.total.toLocaleString()} / Ideal: {currency}{rule_50_30_20_comparison.needs_ideal.toLocaleString()})
                </span>
              </div>
              <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, needs.percentage)}%` }}
                />
              </div>
            </div>

            {/* Wants Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Coffee className="w-3.5 h-3.5 text-amber-500" />
                  <span>Wants (Ideal: 30% max)</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  Actual: {wants.percentage}% ({currency}{wants.total.toLocaleString()} / Ideal: {currency}{rule_50_30_20_comparison.wants_ideal.toLocaleString()})
                </span>
              </div>
              <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, wants.percentage)}%` }}
                />
              </div>
            </div>

            {/* Savings Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Savings & Investments (Ideal: 20%+ target)</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  Actual: {savings.percentage}% ({currency}{savings.actual_surplus.toLocaleString()} / Target: {currency}{rule_50_30_20_comparison.savings_ideal.toLocaleString()})
                </span>
              </div>
              <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, savings.percentage)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-200">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span>Budgeting Rule Guidance</span>
            </div>
            <p className="leading-relaxed">
              The 50/30/20 framework helps maintain liquidity without extreme austerity. If your needs exceed 50%, look into trimming fixed utility bundles or optimizing grocery meal batches.
            </p>
          </div>
        </div>
      </div>

      {/* Itemized Categories: Needs vs Wants Detailed Breakdown Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Needs Itemization */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-500" />
              <h3 className="font-bold text-slate-900 dark:text-white">Needs Breakdown</h3>
            </div>
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400">
              Total {currency}{needs.total.toLocaleString()}
            </span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {Object.entries(needs.breakdown).map(([key, val]) => (
              <div key={key} className="py-2.5 flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400 capitalize">
                  {key.replace(/_/g, ' ')}
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {currency}{Number(val).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Wants Itemization */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-amber-500" />
              <h3 className="font-bold text-slate-900 dark:text-white">Wants Breakdown</h3>
            </div>
            <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
              Total {currency}{wants.total.toLocaleString()}
            </span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {Object.entries(wants.breakdown).map(([key, val]) => (
              <div key={key} className="py-2.5 flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400 capitalize">
                  {key.replace(/_/g, ' ')}
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {currency}{Number(val).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
