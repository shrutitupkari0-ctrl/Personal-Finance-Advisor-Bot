import React from 'react';
import {
  CurrencySymbol,
  FinancialAdviceResponse,
  UserFinancialInput,
} from '../types/finance';
import {
  TrendingUp,
  CreditCard,
  Wallet,
  PiggyBank,
  CheckCircle2,
  AlertTriangle,
  Compass,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  Target,
  Sparkles,
  ChevronRight,
  PieChart as PieIcon,
  BarChart3,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
} from 'recharts';

interface DashboardOverviewProps {
  advice: FinancialAdviceResponse;
  userData: UserFinancialInput;
  currency: CurrencySymbol;
  onNavigate: (tab: string) => void;
}

const EXPENSE_COLORS = [
  '#4F46E5', // Indigo (Housing)
  '#06B6D4', // Cyan (Food)
  '#10B981', // Emerald (Transport)
  '#F59E0B', // Amber (Utilities)
  '#EC4899', // Pink (Entertainment)
  '#8B5CF6', // Purple (Shopping)
  '#3B82F6', // Blue (Healthcare)
  '#64748B', // Slate (Other)
  '#14B8A6', // Teal
];

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  advice,
  userData,
  currency,
  onNavigate,
}) => {
  const { budget_plan, monthly_summary, saving_suggestions, insights } = advice;

  // Prepare Expense Breakdown for Donut Chart
  const expenseBreakdownData: { name: string; value: number }[] = [];
  const baseExpenses = userData.expenses || {};
  for (const [key, val] of Object.entries(baseExpenses)) {
    const amount = Number(val || 0);
    if (amount > 0) {
      const formattedName = key.replace(/([A-Z])/g, ' $1').replace(/^./, (s) => s.toUpperCase());
      expenseBreakdownData.push({ name: formattedName, value: amount });
    }
  }

  // Cash flow comparison data for Bar Chart
  const cashFlowComparison = [
    {
      name: 'Monthly Overview',
      Income: budget_plan.total_income,
      Expenses: budget_plan.total_expenses,
      Surplus: Math.max(0, budget_plan.available_balance),
    },
  ];

  // Savings goal metrics
  const targetGoal = userData.financialGoal || 'Emergency Fund';
  const targetAmt = userData.targetAmount || 150000;
  const currentSavings = userData.currentSavings || 0;
  const goalProgressPct = Math.min(100, Math.round((currentSavings / (targetAmt || 1)) * 100));
  const remainingAmt = Math.max(0, targetAmt - currentSavings);
  const monthlyPace = budget_plan.available_balance > 0 ? budget_plan.available_balance : 2500;
  const monthsRemaining = Math.ceil(remainingAmt / monthlyPace);

  return (
    <div className="space-y-8 py-4 sm:py-6">
      {/* Top Welcome & Subtitle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              Financial Overview
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300">
              Active Plan
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Real-time assessment of your income, expenses, cash surplus, and goal velocity.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('what-if')}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 border border-indigo-200 dark:border-indigo-800 transition flex items-center gap-1.5"
          >
            <span>Run 'What If'</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onNavigate('advisor')}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 transition flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 dark:text-emerald-600" />
            <span>Ask Advisor</span>
          </button>
        </div>
      </div>

      {/* 4 Top Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* 1. Monthly Income */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Monthly Income
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {currency}
              {budget_plan.total_income.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
              <span>Primary: {currency}{userData.income.toLocaleString()}</span>
              {userData.otherIncome > 0 && (
                <span>• Other: {currency}{userData.otherIncome.toLocaleString()}</span>
              )}
            </div>
          </div>
        </div>

        {/* 2. Total Expenses */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Total Expenses
            </span>
            <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {currency}
              {budget_plan.total_expenses.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
              {budget_plan.total_income > 0
                ? `${Math.round((budget_plan.total_expenses / budget_plan.total_income) * 100)}% of monthly inflow`
                : 'Expense total'}
            </div>
          </div>
        </div>

        {/* 3. Available Balance */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Available Balance
            </span>
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                budget_plan.available_balance >= 0
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
                  : 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
              }`}
            >
              {budget_plan.available_balance >= 0 ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
            </div>
          </div>
          <div>
            <div
              className={`text-2xl font-black ${
                budget_plan.available_balance >= 0
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            >
              {currency}
              {budget_plan.available_balance.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
              {budget_plan.savings.percentage}% net savings rate
            </div>
          </div>
        </div>

        {/* 4. Suggested Savings */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Suggested Savings
            </span>
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <PiggyBank className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">
              {currency}
              {budget_plan.savings.recommended_monthly.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
              Target 20% 50/30/20 guideline
            </div>
          </div>
        </div>
      </div>

      {/* Goal Progress Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border border-indigo-900/60 shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Target className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                Priority Goal Tracker
              </span>
              <h3 className="text-base sm:text-lg font-bold text-white">{targetGoal}</h3>
            </div>
          </div>

          <div className="text-left sm:text-right">
            <div className="text-sm font-bold text-emerald-400">
              {currency}{currentSavings.toLocaleString()} / {currency}{targetAmt.toLocaleString()}
            </div>
            <span className="text-xs text-slate-400">
              ~{monthsRemaining} months remaining at current pace
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-1.5">
          <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700">
            <div
              className="h-full rounded-full bg-gradient-to-r from-indigo-500 via-blue-500 to-emerald-400 transition-all duration-700"
              style={{ width: `${goalProgressPct}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-slate-400">
            <span>{goalProgressPct}% funded</span>
            <span>Target gap: {currency}{remainingAmt.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* AI Monthly Summary Card */}
      <section className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-emerald-500 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                AI Monthly Summary
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Synthesis of health, positive observations, and tactical priorities.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Health Rating:</span>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold ${
                monthly_summary.health_score === 'Strong'
                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                  : monthly_summary.health_score === 'Moderate'
                  ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                  : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
              }`}
            >
              {monthly_summary.health_score} ({monthly_summary.health_score_num || 80}/100)
            </span>
          </div>
        </div>

        {/* Narrative Paragraph */}
        <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
          {monthly_summary.overall_summary}
        </p>

        {/* 4 Detail Grid Cells */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Biggest Category */}
          <div className="p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-800 space-y-1">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Largest Expense Outflow
            </span>
            <div className="text-sm font-bold text-slate-900 dark:text-white">
              {monthly_summary.biggest_category}
            </div>
          </div>

          {/* Positive Observation */}
          <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/40 space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Positive Observation</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-normal">
              {monthly_summary.positive_observation}
            </p>
          </div>

          {/* Area to Improve */}
          <div className="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/40 space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Area to Improve</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-normal">
              {monthly_summary.area_to_improve}
            </p>
          </div>

          {/* Next Month Focus */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-indigo-700 dark:text-indigo-400 uppercase tracking-wider">
              <Compass className="w-3.5 h-3.5" />
              <span>Next Month Focus</span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-normal">
              {monthly_summary.next_month_focus}
            </p>
          </div>
        </div>
      </section>

      {/* Visualizations Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Expense Breakdown Donut */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Expense Categorical Breakdown
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-medium">
              Total {currency}{budget_plan.total_expenses.toLocaleString()}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={expenseBreakdownData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {expenseBreakdownData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={EXPENSE_COLORS[index % EXPENSE_COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${currency}${Number(val).toLocaleString()}`, 'Amount']}
                  contentStyle={{
                    backgroundColor: '#1E293B',
                    borderRadius: '8px',
                    border: 'none',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Categorical Legend Pill Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px]">
            {expenseBreakdownData.map((item, idx) => (
              <div key={item.name} className="flex items-center gap-1.5 truncate">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: EXPENSE_COLORS[idx % EXPENSE_COLORS.length] }}
                />
                <span className="text-slate-600 dark:text-slate-400 truncate">{item.name}</span>
                <span className="font-bold text-slate-900 dark:text-white ml-auto">
                  {currency}{item.value.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Chart 2: Cash Flow Bar Chart */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Monthly Inflow vs Outflow
              </h3>
            </div>
            <span className="text-xs text-slate-400 font-medium">Cash Flow Ratio</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cashFlowComparison} margin={{ top: 20, right: 20, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#94A3B8' }} />
                <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                <Tooltip
                  formatter={(val: any) => [`${currency}${Number(val).toLocaleString()}`, '']}
                  contentStyle={{
                    backgroundColor: '#1E293B',
                    borderRadius: '8px',
                    border: 'none',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Bar dataKey="Income" fill="#4F46E5" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Expenses" fill="#F43F5E" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Surplus" fill="#10B981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
            <span>Monthly Net Surplus:</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400">
              +{currency}{budget_plan.available_balance.toLocaleString()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
