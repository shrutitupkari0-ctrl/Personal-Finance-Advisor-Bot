import React, { useEffect, useState } from 'react';
import { Sparkles, BrainCircuit, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface LoadingAnalysisProps {
  onCancel?: () => void;
}

const STEPS = [
  'Auditing monthly income and fixed expense commitments...',
  'Evaluating 50/30/20 Needs, Wants, and Savings ratios...',
  'Identifying spending anomalies and lifestyle leakages...',
  'Consulting Gemini AI model for personalized tactical suggestions...',
  'Synthesizing milestone projections and executive summary...',
];

export const LoadingAnalysis: React.FC<LoadingAnalysisProps> = () => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentStepIndex((prev) => (prev < STEPS.length - 1 ? prev + 1 : prev));
    }, 1200);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-[460px] flex items-center justify-center p-6">
      <div className="max-w-md w-full p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl text-center space-y-6 relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-2 bg-gradient-to-r from-indigo-500 via-blue-500 to-emerald-400 blur-xs" />

        {/* Animated Radar / Brain Icon */}
        <div className="relative mx-auto w-20 h-20 flex items-center justify-center">
          <div className="absolute inset-0 rounded-2xl bg-indigo-500/20 dark:bg-indigo-500/30 animate-ping opacity-60" />
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-emerald-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
            <Sparkles className="w-8 h-8 animate-spin-slow" />
          </div>
        </div>

        {/* Main Heading */}
        <div className="space-y-1.5">
          <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
            VanguardIQ is analyzing your finances...
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Synthesizing personal budget allocations and AI saving opportunities.
          </p>
        </div>

        {/* Dynamic Step Progress */}
        <div className="space-y-2.5 text-left bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
          {STEPS.map((step, idx) => {
            const isCompleted = idx < currentStepIndex;
            const isCurrent = idx === currentStepIndex;
            return (
              <div
                key={step}
                className={`flex items-center gap-2.5 text-xs transition-opacity duration-300 ${
                  isCompleted
                    ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                    : isCurrent
                    ? 'text-indigo-600 dark:text-indigo-400 font-bold animate-pulse'
                    : 'text-slate-400 dark:text-slate-600'
                }`}
              >
                {isCompleted ? (
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-500" />
                ) : (
                  <div
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      isCurrent ? 'bg-indigo-600 ring-4 ring-indigo-100 dark:ring-indigo-900/50' : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                  />
                )}
                <span className="truncate">{step}</span>
              </div>
            );
          })}
        </div>

        {/* Bottom Security Note */}
        <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>Processing encrypted in-memory model inference</span>
        </div>
      </div>
    </div>
  );
};
