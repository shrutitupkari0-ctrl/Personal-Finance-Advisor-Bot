export type CurrencySymbol = '₹' | '$' | '€' | '£' | '¥';

export interface ExpenseItem {
  id: string;
  name: string;
  category: string;
  amount: number;
}

export interface UserFinancialInput {
  income: number;
  otherIncome: number;
  currency: CurrencySymbol;
  expenses: {
    housing: number;
    food: number;
    transportation: number;
    utilities: number;
    entertainment: number;
    shopping: number;
    education: number;
    healthcare: number;
    other: number;
    [key: string]: number;
  };
  customExpenses?: ExpenseItem[];
  financialGoal: string;
  targetAmount: number;
  targetDate: string;
  currentSavings: number;
  riskPreference: 'Conservative' | 'Balanced' | 'Aggressive';
  notes: string;
}

export interface SavingSuggestion {
  id: string;
  title: string;
  explanation: string;
  potential_saving: string;
  priority: 'High' | 'Medium' | 'Low';
  category?: string;
}

export interface MonthlySummary {
  health_score: string;
  health_score_num: number;
  overall_summary: string;
  biggest_category: string;
  savings_progress: string;
  positive_observation: string;
  area_to_improve: string;
  next_month_focus: string;
}

export interface InsightItem {
  title: string;
  value: string;
  description: string;
}

export interface BudgetPlan {
  total_income: number;
  total_expenses: number;
  available_balance: number;
  needs: {
    total: number;
    percentage: number;
    breakdown: {
      housing: number;
      food: number;
      transportation: number;
      utilities: number;
      healthcare: number;
      education: number;
      [key: string]: number;
    };
  };
  wants: {
    total: number;
    percentage: number;
    breakdown: {
      entertainment: number;
      shopping: number;
      other: number;
      [key: string]: number;
    };
  };
  savings: {
    recommended_monthly: number;
    actual_surplus: number;
    percentage: number;
  };
  rule_50_30_20_comparison: {
    needs_ideal: number;
    wants_ideal: number;
    savings_ideal: number;
    status: string;
  };
}

export interface FinancialAdviceResponse {
  budget_plan: BudgetPlan;
  saving_suggestions: SavingSuggestion[];
  monthly_summary: MonthlySummary;
  insights: InsightItem[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}
